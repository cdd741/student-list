import "./App.css";
// import Searchbar from "./components/Searchbar";
import ProfilesContainer from "./components/ProfilesContainer";

function App() {
  return (
    <div className="App">
      <ProfilesContainer />
    </div>
  );
}

export default App;
